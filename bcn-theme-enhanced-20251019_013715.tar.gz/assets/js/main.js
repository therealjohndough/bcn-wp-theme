/**
 * Main JavaScript file
 *
 * @package BCN_WP_Theme
 */

(function($) {
    'use strict';

    
    $(document).ready(function() {
        
        $(window).on('scroll', function() {
            if ($(window).scrollTop() > 100) {
                $('body').addClass('scrolled');
            } else {
                $('body').removeClass('scrolled');
            }
        });

        
        $('.skip-link').on('click', function(e) {
            var target = $(this).attr('href');
            $(target).attr('tabindex', '-1').focus();
        });

        
        $('.main-navigation').find('a').on('focus blur', function() {
            $(this).parents('li').toggleClass('focus');
        });

        
        $('a[href^="http"]').not('a[href*="' + window.location.hostname + '"]').attr({
            target: '_blank',
            rel: 'noopener noreferrer'
        });
    });

    
    $(window).on('load', function() {
        
        $('body').removeClass('loading');
    });

})(jQuery);
